NIL-AI Minister Review Bundle
Run: NIL-AI-2026-0611

Contains PDF report + Excel attribute register.